DROP DATABASE IF EXISTS MASS_SCHOOLS_DATABASE;

CREATE DATABASE MASS_SCHOOLS_DATABASE;

USE MASS_SCHOOLS_DATABASE;

CREATE TABLE district(
	district_name VARCHAR(255),
    district_id INT PRIMARY KEY);
    
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/Districts.csv'
INTO TABLE district
FIELDS TERMINATED by ','
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

CREATE TABLE attendance(
	district_id INT,
    FOREIGN KEY(district_id) REFERENCES district(district_id),
    attendance_rate float,
    avg_absences float,
    avg_absent_over_10 float,
    avg_chronic_absence float,
    avg_unexcused_over_10 float);
    
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/Attendance.csv'
INTO TABLE attendance
FIELDS TERMINATED by ','
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

CREATE TABLE class_size(
	district_id INT,
    FOREIGN KEY(district_id) REFERENCES district(district_id),
    number_of_classes INT,
    avg_class_size float);
    
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/ClassSize.csv'
INTO TABLE class_size
FIELDS TERMINATED by ','
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

CREATE TABLE salaries(
	district_id INT,
    FOREIGN KEY(district_id) REFERENCES district(district_id),
    salary_totals BIGINT,
    avg_salary INT,
    fte_count INT);
    
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/Salaries.csv'
INTO TABLE salaries
FIELDS TERMINATED by ','
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

CREATE TABLE sat(
	district_id INT,
	FOREIGN KEY(district_id) REFERENCES district(district_id),
    tests_taken INT,
    reading_writing INT,
    math INT NULL);

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/SAT.csv'
INTO TABLE sat
FIELDS TERMINATED BY ',' 
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

CREATE TABLE mcas(
	district_id INT,
	FOREIGN KEY(district_id) REFERENCES district(district_id),
    subject varchar(5),
    number_students INT,
    participation_rate INT,
    avg_scaled_score INT);

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/MCAS.csv'
INTO TABLE mcas
FIELDS TERMINATED by ','
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

CREATE TABLE student_demographics(
	district_id INT,
	FOREIGN KEY(district_id) REFERENCES district(district_id),
    number_students INT,
    african_american INT,
    asian INT,
    hispanic INT,
    white INT,
    native_american INT,
    pacific_islander INT,
    multi_race INT,
    males float,
    females float,
    non_binary float,
    english_learner float,
    disabilities float,
    econimically_disadvantaged float);
    
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/STUDENT_Demographics.csv'
INTO TABLE student_demographics
FIELDS TERMINATED by ','
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

CREATE TABLE STAFF_demographics(
	district_id INT,
	FOREIGN KEY(district_id) REFERENCES district(district_id),
    african_american INT,
    asian INT,
    hispanic INT,
    white INT,
    native_american INT,
    pacific_islander INT,
    multi_race INT,
    females float,
    males float);
    
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/STAFF_demographics.csv'
INTO TABLE STAFF_demographics
FIELDS TERMINATED by ','
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

CREATE TABLE educator_eval (
    district_id INT,
    percent_evaluated VARCHAR(255),
    percent_exemplary VARCHAR(255),
    percent_proficient VARCHAR(255),
    percent_needs_improvement VARCHAR(255),
    percent_unsatisfactory VARCHAR(255),
    FOREIGN KEY (district_id) REFERENCES district(district_id)
);

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/EducatorEvalPerf.csv'
INTO TABLE educator_eval
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(district_id, percent_evaluated, percent_exemplary, percent_proficient, percent_needs_improvement, percent_unsatisfactory);

